# Hastane_Y-netim_Otomasyonu
MSSQL Ado.Net ve Windows Form ile grupça yaptığımız hastane yönetim otomasyonu  
